""" rmon.extensions

rmon 项目使用的所有扩展
"""
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()
