import optparse
from models import server


class ParamsHandler:
    def __init__(self):
        self.op = optparse.OptionParser()
        self.op.add_option('-s', '--server', dest='server')
        self.op.add_option('-p', '--port', dest='port')
        options, args = self.op.parse_args()
        self.server = server.TCPServer()
        self.checkParams(options, args)

    def checkParams(self, options, args):
        cmd = args[0]
        if hasattr(self, cmd):
            func = getattr(self, cmd)
            func()

    def start(self):
        self.server.start()

    def stop(self):
        self.server.stop()
