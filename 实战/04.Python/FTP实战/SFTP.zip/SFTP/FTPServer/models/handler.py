import socketserver


class RequestHandler(socketserver.BaseRequestHandler):
    def handle(self):
        print('ok')
