import socketserver
from models import handler


class TCPServer:
    def __init__(self):
        self.server = socketserver.ThreadingTCPServer(('localhost', 8888), handler.RequestHandler)

    def start(self):
        print('Start Server...')
        self.server.serve_forever()

    def stop(self):
        print('Stop Server...')
