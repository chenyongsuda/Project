import socket

sk = socket.socket()
con = sk.connect(('127.0.0.1', 8888))


