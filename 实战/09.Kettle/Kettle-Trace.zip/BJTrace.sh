source /etc/environment
export PATH="/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin"
/data/kettle/pdi/kitchen.sh -rep Kettle -user admin -pass admin -dir /BJTrace -job BJTrace
